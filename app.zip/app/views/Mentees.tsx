import React from 'react';
import { Text, View } from 'react-native';

const Mentees = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <Text>Mentees</Text>
    </View>
  );
};

export default Mentees;
