import React from 'react';
import { Text, View } from 'react-native';

const Person = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <Text>Tab Person</Text>
    </View>
  );
};

export default Person;
