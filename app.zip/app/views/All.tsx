import React from 'react';
import { Text, View } from 'react-native';

const All = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <Text> All</Text>
    </View>
  );
};

export default All;
