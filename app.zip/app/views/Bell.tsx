import React from 'react';
import { Text, View } from 'react-native';

const Bell = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <Text>Tab bell</Text>
    </View>
  );
};

export default Bell;
