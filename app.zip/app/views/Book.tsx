import React from 'react';
import { Text, View } from 'react-native';

const Book = () => {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <Text>Tab Book</Text>
    </View>
  );
};

export default Book;
