# Services

This module contains any constant singleton "services" that should be accessible
throughout the application. Anything exported here will also be made available
to the epics in the `store` module.