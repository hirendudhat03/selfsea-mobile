import Right from '../assets/images/pngs/Vector.png';
import Warning from '../assets/images/pngs/exclamation-triangle.png';
import Circle from '../assets/images/pngs/x-circle.png';
import Send from '../assets/images/pngs/logo-s-red-1.png';
import Google from '../assets/images/pngs/google.png';
import Instagram from '../assets/images/pngs/instagram.png';
import Apple from '../assets/images/pngs/applelogo.png';
import Background from '../assets/images/pngs/background.png';
import Logo from '../assets/images/pngs/logo.png';
import DropdownIcon from '../assets/images/pngs/dropdown-button-carot-down.png';
import Cross from '../assets/images/pngs/cross.png';
import Bell from '../assets/images/pngs/bell.png';
import Book from '../assets/images/pngs/book.png';
import House from '../assets/images/pngs/house-door.png';
import Person from '../assets/images/pngs/person-circle.png';
import Pencil from '../assets/images/pngs/pencil-square.png';
import Gear from '../assets/images/pngs/gear.png';
import Arrow from '../assets/images/pngs/arrow-left-square-fill.png';
import Downarrow from '../assets/images/pngs/caret-down-square-fill.png';
import Infocircle from '../assets/images/pngs/infoCircle.png';
import Arrowsquare from '../assets/images/pngs/arrowLeftSquareFill.png';
import LogoTab from '../assets/images/pngs/logo-diamond.png';
import MenuDropdown from '../assets/images/pngs/chevron-down.png';
import DrawerLogo from '../assets/images/pngs/drawerLogo.png';
import MenuDropdownup from '../assets/images/pngs/chevron-up.png';
import PasswordIcon from '../assets/images/pngs/visibility.png';
import visibilityShow from '../assets/images/pngs/visibilityShow.png';
import HomeFill from '../assets/images/pngs/home.png';
import BellFill from '../assets/images/pngs/bellfill.png';
import BookFill from '../assets/images/pngs/open-book.png';
import PersonFill from '../assets/images/pngs/user.png';
import plusCircle from '../assets/images/pngs/plusCircle.png';
import Dots from '../assets/images/pngs/three-dots.png';
import CheckCircle from '../assets/images/pngs/checkCircleFill.png';
import CheckCircleGreen from '../assets/images/pngs/checkCircleFillGreen.png';
import combinedShape from '../assets/images/pngs/combinedShape.png';
import combinedShapeOPen from '../assets/images/pngs/combinedShapeOPen.png';
import xCircle from '../assets/images/pngs/xCircle.png';
import infoCircleFill from '../assets/images/pngs/infoCircleFill.png';

const images = {
  Right,
  Warning,
  Circle,
  Send,
  Google,
  Instagram,
  Apple,
  Background,
  Logo,
  DropdownIcon,
  Cross,
  Bell,
  Book,
  House,
  Person,
  Pencil,
  Gear,
  Arrow,
  Downarrow,
  Infocircle,
  Arrowsquare,
  LogoTab,
  MenuDropdown,
  DrawerLogo,
  MenuDropdownup,
  PasswordIcon,
  visibilityShow,
  HomeFill,
  BellFill,
  BookFill,
  PersonFill,
  plusCircle,
  Dots,
  CheckCircle,
  CheckCircleGreen,
  combinedShape,
  combinedShapeOPen,
  xCircle,
  infoCircleFill,
};
export default images;
