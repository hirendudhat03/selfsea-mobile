export default {
  CALIBRE: 'Calibre',
};
