import * as userActions from './user/actions';

export default {
  user: userActions,
};
